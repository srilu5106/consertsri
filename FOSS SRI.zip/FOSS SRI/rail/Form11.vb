﻿Public Class Form11
    Dim Num1 As Integer
    Dim Num2 As Integer
    Dim Ans As Integer

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub Form11_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TicketfareDataSet.ticket' table. You can move, or remove it, as needed.
        Me.TicketTableAdapter.Fill(Me.TicketfareDataSet.ticket)

    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Num1 = TextBox7.Text
        If ComboBox2.SelectedItem = "GOLD" Then
            Num2 = TextBox3.Text
        End If
        If ComboBox2.SelectedItem = "SILVER" Then
            Num2 = TextBox4.Text
        End If
        If ComboBox2.SelectedItem = "PLATINUM" Then
            Num2 = TextBox5.Text
        End If
        If ComboBox2.SelectedItem = "BOX" Then
            Num2 = TextBox6.Text
        End If
        Ans = Num1 * Num2
        TextBox8.Text = Ans
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Form13.Show()
        Me.Close()
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged

    End Sub

 
    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

   
   
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub
End Class